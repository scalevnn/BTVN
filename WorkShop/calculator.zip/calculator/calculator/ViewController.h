//
//  ViewController.h
//  calculator
//
//  Created by TechMaster on 3/19/14.
//  Copyright (c) 2014 TechMaster. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@end
