//
//  AppDelegate.h
//  calculator
//
//  Created by TechMaster on 3/19/14.
//  Copyright (c) 2014 TechMaster. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
