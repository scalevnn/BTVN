//
//  ViewController.m
//  calculator
//
//  Created by TechMaster on 3/19/14.
//  Copyright (c) 2014 TechMaster. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
@property (weak, nonatomic) IBOutlet UILabel *resultLabel;

@end
double s1,s5,s6, s2, result;
int choose;
float s3,s4;
NSMutableString * string ;
@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    s1=s2=1;
    s5=0;
    self.resultLabel.text = @"";
}
- (IBAction)onNumeric:(id)sender {
    
    UIButton * button = (UIButton*) sender;
    NSString* key = [button titleForState:UIControlStateNormal];
    string = [NSMutableString stringWithString:self.resultLabel.text];
    [string appendString:key];
    
    self.resultLabel.text = string;
    
    
}
- (IBAction)del:(id)sender {
    s1=s2=1;
    result=0;
    self.resultLabel.text = @"";
}
- (IBAction)chia:(id)sender {
   
    s1 = [string intValue];
    s2=s1;
    string=[NSMutableString stringWithString:@" "];
    self.resultLabel.text = @"";
    choose =4;
    
}
- (IBAction)nhan:(id)sender {
    
    s1 = [string intValue];
    s2*=s1;
    string=[NSMutableString stringWithString:@""];
    choose =3;
    self.resultLabel.text = @""	;
    
}
- (IBAction)tru:(id)sender {
    
    s1 = [string intValue];
    s2=s1;
    string=[NSMutableString stringWithString:@""];
    choose =2;
    self.resultLabel.text = @"";
    
}
- (IBAction)cong:(id)sender {
    s2=0;
    s1 = [string intValue];
    s2+=s1;
    string=[NSMutableString stringWithString:@""];
    choose =1;
    self.resultLabel.text = string;
    
}

- (IBAction)result:(id)sender {
    if (choose==1) {
        s1 = [string intValue];
        s2+=s1;
        s5+=s2;
        self.resultLabel.text = [NSString stringWithFormat:@"%2.f",s5];
        s2=s1=0;
        string=[NSMutableString stringWithString:@""];
    }
    else if (choose==2) {
        
        s1 = [string intValue];
        if(result !=0)
        { s2=result;}
        result=s2-s1;
        self.resultLabel.text = [NSString stringWithFormat:@"%2.f",result];
        s1=s2=0;
    }
    else if (choose==3) {
        s1 = [string intValue];
        if(result !=0)
        { s2=result;}
        result=s1 * s2;
        self.resultLabel.text = [NSString stringWithFormat:@"%2.f",result];
        
    }
    else if (choose==4) {
        
        s1 = [string intValue];
        if(result!=0)
        { s2=result;}
        result=s2/s1;
        self.resultLabel.text = [NSString stringWithFormat:@"%2.f",result];
        s2=s1=1;
        string=[NSMutableString stringWithString:@""];
        
    }
}

@end
